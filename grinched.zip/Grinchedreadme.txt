TrueTypeFont: Grinched
Dennis Ludlow Productions 2000 all rights reserved
Sharkshock Productions

What's up Seuss fans? This font as well as all the others on my site are free for download for non-commercial  use only.
For commercial purposes contact me at dennis@sharkshock.net or visit www.sharkshock.net/license

